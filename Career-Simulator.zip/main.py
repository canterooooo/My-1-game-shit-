import random
import footy
import basket
import amerfoot
import time

from footy import main

from basket import basmain

from amerfoot import footmain


print("WELCOME TO THE CAREER SIMULATOR")
time.sleep(2)
print("\nThe journey to fame is in your hands. Select your path wisely and decide the career mode that strikes your intrest. Navigate critical transfer choices strategically to unlock your true potential. Opt for the right moves, and you'll ascend to the status of the G.O.A.T. However, beware, as a single misstep could lead you on the wrong path. Your destiny hangs in the balance, and the power to shape it rests entirely with you.\n")


while True:
  mode = int(input("\nPlease choose which type of career mode you want to play \n(1) Football \n(2) Basketball \n(3) American football   \n: "))

  if mode == 1:
    main()
  elif mode == 2:
    basmain()
  elif mode == 3:
    footmain()