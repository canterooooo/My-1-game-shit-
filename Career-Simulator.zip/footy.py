import random


def introduction():
    print("Welcome to the Football Career Simulator!")
    print(
        "\nIn this game, you will experience the entire journey of a football player, from your early days in the academy to managing a team. Your ultimate goal is to reach the peak of your career and become a legendary football figure."
    )


def better_nations():
    better_nations = [
        "Brazil", "Germany", "Argentina", "Italy", "France", "England",
        "Spain", "Portugal", "Uruguay", "Netherlands"
    ]
    random.shuffle(better_nations)
    n1 = better_nations.pop()
    return n1


def mid_nations():
    mid_nations = [
        "Belgium", "Chile", "Colombia", "Mexico", "Croatia", "Switzerland",
        "Sweden", "Denmark", "Sweden", "Senegal", "Poland", "Ukraine", "Peru",
        "Austria", "Wales", "Nigeria"
    ]
    random.shuffle(mid_nations)
    n2 = mid_nations.pop()
    return n2


def bad_nations():
    bad_nations = [
        "Ghana", "Paraguay", "Serbia", "Algeria",
        "Ivory Coast (Côte d'Ivoire)", "Romania", "Greece", "Czech Republic",
        "United States", "Japan"
    ]
    random.shuffle(bad_nations)
    n3 = bad_nations.pop()
    return n3


def big_teams():
    big_teams = [
        "Manchester City (England)", "Real Madrid (Spain)",
        "Bayern Munich (Germany)", "Liverpool (England)", "Arsenal (England)",
        "Barcelona (Spain)", "Atlético Madrid (Spain)", "Napoli (Italy)",
        "AC Milan (Italy)", "Benfica (Portugal)",
        "Paris Saint-Germain (France)", "Juventus (Italy)",
        "Manchester United (England)", "Chelsea (England)",
        "Marseille (France)", "Villarreal (Spain)", "Ajax (Netherlands)",
        "Galatasaray (Turkey)", "Shakhtar Donetsk (Ukraine)",
        "Internacional (Brazil)", "Corinthians (Brazil)",
        "Al Nassr (Saudi Arabia)", "RB Leipzig (Germany)",
        "Real Sociedad (Spain)", "Bayer Leverkusen (Germany)",
        "Aston Villa (England)", "Tottenham Hotspur (England)",
        "Feyenoord (Netherlands)", "Sporting CP (Portugal)",
        "Inter Milan (Italy)", "Borussia Dortmund (Germany)",
        "Al Ahly (Egypt)", "Al-Hilal (Saudi Arabia)", "Al-Ahli (Saudi Arabia)",
        "Persepolis (Iran)", "Al-Duhail (Qatar)"
    ]
    random.shuffle(big_teams)
    big_team = big_teams.pop()
    return big_team


def small_teams():
    small_teams = [
        "Zenit St. Petersburg (Russia)", "Boca Juniors (Argentina)",
        "Lazio (Italy)", "Fiorentina (Italy)", "Red Bull Salzburg (Austria)",
        "Brighton & Hove Albion (England)", "West Ham (England)",
        "Lens (France)", "Braga (Portugal)", "Brentford (England)",
        "Flora Tallinn (Estonia)", "Sparta Prague (Czech Republic)",
        "Nice (France)", "Freiburg (Germany)", "Celtic (Scotland)",
        "Eintracht Frankfurt (Germany)", "Monaco (France)", "Lille (France)",
        "Fluminense FC (Brazil)", "Roma (Italy)", "Sevilla (Spain)",
        "VfL Wolfsburg (Germany)", "Crystal Palace (England)",
        "América (Mexico)", "Rangers (Scotland)", "FC Twente (Netherlands)",
        "Fulham (England)", "Wolverhampton Wanderers (England)",
        "FC Sheriff (Moldova)", "Union Saint-Gilloise (Belgium)",
        "Estudiantes de la Plata (Argentina)", "Leicester City (England)",
        "Auckland City (New Zealand)", "Mallorca (Spain)",
        "Bodø/Glimt (Norway)", "Bahia (Brazil)", "Nottingham Forest (England)",
        "Cádiz CF (Spain)", "Gent (Belgium)", "Cuiaba (Brazil)",
        "Dinamo Minsk (Belarus)", "Shamrock Rovers (Ireland)",
        "Ulsan Hyundai (South Korea)", "CFR Cluj (Romania)",
        "Sassuolo (Italy)", "Argentinos Juniors (Argentina)", "Reims (France)",
        "Racing Club (Argentina)", "Tigres UANL (Mexico)"
    ]
    random.shuffle(small_teams)
    small_team = small_teams.pop()
    return small_team


def choose_position():
    print("Choose your position:")
    print("1. Goalkeeper")
    print("2. Defender")
    print("3. Midfielder")
    print("4. Striker")
    while True:
        choice = input("Enter the number of your choice: ")
        if choice in ["1", "2", "3", "4"]:
            positions = {
                1: "Goalkeeper",
                2: "Defender",
                3: "Midfielder",
                4: "Striker"
            }
            position = positions[int(choice)]
            print(f"You chose to play as a {position}")
            return position
        else:
            print("Invalid choice. Please enter a number between 1 and 4.")


def nationality(NationA, NationB, NationC):
    national_team = random.randint(1, 3)
    if national_team == 1:
        print(f"Nationality - {NationA}")
        return NationA
    elif national_team == 2:
        print(f"Nationality - {NationB}")
        return NationB
    else:
        print(f"Nationality - {NationC}")
        return NationC


def choose_academy(ATeam, BTeam):
    academy_team = random.randint(1, 3)
    if academy_team == 1:
        print(f"Academy Team - {ATeam}")
        return ATeam
    else:
        print(f"Academy Team - {BTeam}")
        return BTeam


def sim(ATeam, BTeam, team_name, nation):
    age = 18
    current_team = team_name
    chosen_team = current_team
    team_history = [current_team]

    while age <= 34:
        print(f"\nAge - {age}")

        if age >= 34:
            retirement_option = retirement(team_name, ATeam, BTeam,
                                           current_team)
            current_team = retirement_option
            team_history.append(current_team)
            print_team_timeline(team_history, nation)
            explode = random.randint(1, 3)
            if explode == 1:
                age += 10
            elif explode == 2:
                age += 5
            else:
                age += 3
            return retirement_option

        teams = random.randint(1, 4) if age == 18 else random.randint(1, 4)
        option1, price1 = get_team_and_price(teams, current_team)
        option2, price2 = get_team_and_price(teams, current_team)

        num_options = random.randint(1, 5)
        if current_team == ATeam:
            num_options = random.randint(1, 4)

        if option1 == option2:
            num_options = random.randint(1, 3)

        if num_options == 1:
            decision = input(
                f"Do you want to go to {option1} for £{price1}M (y/n)?: "
            ).strip().lower()
        elif num_options == 2:
            decision = input(
                f"Do you want to go to {option2} for £{price2}M (y/n)?: "
            ).strip().lower()
        elif num_options == 4:
            decision = input(
                f"Do you want to go to (1){option1} for £{price1}M or do you want to go to (2){option2} for £{price2}M(1 or 2)?: "
            ).strip().lower()
        elif num_options == 3:
            print(f"No teams want you so you stay at {current_team}")
            decision = '3'
        else:
            decision = input(
                f"Do you want to go to \n(1) {option1} for £{price1}M \n(2) {option2} for £{price2}M \n(3) stay at {current_team}\nPlease input the number of your choice: "
            ).strip()

        if num_options == 1:
            if decision == "y":
                chosen_team = option1
                print(f"You moved to {chosen_team}")
            elif decision == "n":
                print(f"You stayed at {current_team}")
            else:
                print(f"Invalid Input please input y or n")
                continue
        elif num_options == 2:
            if decision == "y":
                chosen_team = option2
                print(f"You moved to {chosen_team}")
            elif decision == "n":
                print(f"You stayed at {current_team}")
            else:
                print(f"Invalid Input please input y or n")
                continue
        elif num_options == 3:
            print(f"You stayed at {current_team}")
        elif num_options == 4:
            if decision == "1":
                chosen_team = option1
            elif decision == "2":
                chosen_team = option2
                print(f"You moved to {chosen_team}")
            else:
                print(f"Invalid Input please input 1 or 2")
                continue
        elif num_options == 5:
            if decision == "1":
                chosen_team = option1
                print(f"You moved to {chosen_team}")
            elif decision == "2":
                chosen_team = option2
                print(f"You moved to {chosen_team}")
            elif decision == "3":
                print(f"You stayed at {current_team}")
            else:
                print(f"Invalid Input please choose a number 1, 2 or 3")
                continue

        current_team = chosen_team
        team_history.append(current_team)
        age += 2

    print("\nYour career timeline:")
    print(f"Nationality - {nation}")
    print_team_timeline(team_history, nation)
    return current_team


def print_team_timeline(team_history, nation):
    age = 18
    print("\nYour career timeline:")
    print(f"Nationality - {nation}")
    for team in team_history:
        print(f"{age} - {team}")
        age += 2
    print(f"Retired at {age} years old")


def get_team_and_price(teams, current_team):
    if teams == 1:
        team = big_teams()
        while team == current_team:
            team = big_teams()
        price = random.uniform(2.1, 300)
        price = round(price, 1)
    else:
        team = small_teams()
        while team == current_team:
            team = small_teams()
        price = random.uniform(2.1, 50)
        price = round(price, 1)
    return team, price


def retirement(team_name, ATeam, BTeam, current_team):
    print("Retirement\nChoose where you are going to retire.")
    print(f"(1) {ATeam}\n(2) {BTeam}\n(3) {current_team}")

    decision = input("Enter the number of the team where you want to retire: ")

    if decision == "1":
        print(f"You retired at {ATeam}")
        return ATeam
    elif decision == "2":
        print(f"You retired at {BTeam}")
        return BTeam
    elif decision == "3":
        print(f"You retired at {current_team}")
        return current_team
    else:
        print("Invalid input. Please try again.")
        return retirement(team_name, ATeam, BTeam, current_team)


def management(team_name, ATeam, BTeam, current_team):
    print("Management\nChoose which club you want to manage.")
    teams = random.randint(1, 2)
    option1, price1 = get_team_and_price(teams)
    option2, price2 = get_team_and_price(teams)

    decision = input(
        f"Do you want to manage (1) {option1} for £{price1}M or (2) {option2} for £{price2}M (1 or 2)?: "
    )
    if decision == "1":
        print(f"You manage {option1} for the next five years")
        return option1
    elif decision == "2":
        print(f"You manage {option2} for the next five years")
        return option2
    elif decision == "3":
        print(f"You stay and manage {current_team} for the next five years")
    else:
        print("Invalid input. Please try again.")
    return management(team_name, ATeam, BTeam, current_team)


def stats(position, nation, NationA, NationB, team_name):
    statistics = {
        "Position": position,
        "Appearances": random.randint(200, 1400),
        "Clean Sheets": 0,  # Initialize with 0 instead of None
        "Assists": 0,  # Initialize with 0 instead of None
        "Goals": 0,  # Initialize with 0 instead of None
        "Yellow Cards": random.randint(0, 300),
        "Red Cards": random.randint(0, 100),
        "League Titles": random.randint(0, 22),
        "Champions League": random.randint(0, 12),
        "World Cups": 0,  # Initialize with 0 instead of None
        "Ballon d'Or": 0  # Initialize with 0 instead of None
    }

    if position == "Goalkeeper":
        statistics["Clean Sheets"] = random.randint(50, 600)
        statistics["Goals"] = random.randint(0, 25)
        statistics["Assists"] = random.randint(0, 25)
        statistics["Ballon d'Or"] = random.randint(0, 100)
        if statistics["Ballon d'Or"] == 1:
            statistics["Ballon d'Or"] += 1
        else:
            statistics["Ballon d'Or"] = 0
    elif position == "Defender":
        statistics["Clean Sheets"] = random.randint(50, 300)
        statistics["Goals"] = random.randint(0, 150)
        statistics["Assists"] = random.randint(0, 150)
        statistics["Ballon d'Or"] = random.randint(0, 2)
    elif position == "Midfielder":
        statistics["Assists"] = random.randint(50, 700)
        statistics["Goals"] = random.randint(50, 400)
        statistics["Ballon d'Or"] = random.randint(0, 4)
    elif position == "Striker":
        statistics["Assists"] = random.randint(50, 400)
        statistics["Goals"] = random.randint(100, 800)
        statistics["Ballon d'Or"] = random.randint(0, 8)

    if nation in NationA:
        statistics["World Cups"] = random.randint(0, 4)
    elif nation in NationB:
        statistics["World Cups"] = random.randint(0, 2)
    else:
        statistics["World Cups"] = random.randint(0, 1)

    if ("Goals" in statistics and statistics["Goals"] is not None and statistics["Goals"] <= 500) or \
                 ("Assists" in statistics and statistics["Assists"] is not None and statistics["Assists"] <= 400):
        if "Ballon d'Or" in statistics and statistics[
                "Ballon d'Or"] is not None:
            statistics["Ballon d'Or"] -= 5
            statistics["Ballon d'Or"] = max(0, statistics["Ballon d'Or"])

    if ("Goals" in statistics and statistics["Goals"] is not None and statistics["Goals"] <= statistics["Appearances"]) or \
                 ("Assists" in statistics and statistics["Assists"] is not None and statistics["Assists"] <= statistics["Appearances"]):
        if "Ballon d'Or" in statistics and statistics[
                "Ballon d'Or"] is not None:
            statistics["Ballon d'Or"] += 1
            statistics["Ballon d'Or"] = max(0, statistics["Ballon d'Or"])

    if ("League Titles" in statistics
            and statistics["League Titles"] is not None
            and statistics["League Titles"] >= 12):
        if "Ballon d'Or" in statistics and statistics[
                "Ballon d'Or"] is not None:
            statistics["Ballon d'Or"] += 1
            statistics["Ballon d'Or"] = max(0, statistics["Ballon d'Or"])

    if ("Champions League" in statistics
            and statistics["Champions League"] is not None
            and statistics["Champions League"] >= 7):
        if "Ballon d'Or" in statistics and statistics[
                "Ballon d'Or"] is not None:
            statistics["Ballon d'Or"] += 1
            statistics["Ballon d'Or"] = max(0, statistics["Ballon d'Or"])

    return statistics


def get_player_status(player_stats, position):
    goals_scored = player_stats.get("Goals", 0)
    assists = player_stats.get("Assists", 0)
    ballon_dor = player_stats.get("Ballon d'Or", 0)
    clean_sheets = player_stats.get("Clean Sheets", 0)

    if position.lower() == "striker" or position.lower() == "midfielder":
        if ballon_dor >= 7:
            return "G.O.A.T"
        elif goals_scored + assists < 300:
            return "Unknown"
        elif 300 <= goals_scored + assists < 500:
            return "Failed Wonderkid"
        elif 500 <= goals_scored + assists < 750:
            return "Well-Known"
        elif 750 <= goals_scored + assists < 1000:
            return "Legend"
        else:
            return "G.O.A.T"
    elif position.lower() == "defender":
        if ballon_dor >= 4:
            return "G.O.A.T"
        elif clean_sheets < 50:
            return "Unknown"
        elif 150 <= clean_sheets < 215:
            return "Failed Wonderkid"
        elif 215 <= clean_sheets < 320:
            return "Well-Known"
        elif 320 <= clean_sheets < 500:
            return "Legend"
        else:
            return "G.O.A.T"
    else:
        if ballon_dor >= 2:
            return "G.O.A.T"
        elif clean_sheets < 50:
            return "Unknown"
        elif 150 <= clean_sheets < 215:
            return "Failed Wonderkid"
        elif 215 <= clean_sheets < 320:
            return "Well-Known"
        elif 320 <= clean_sheets < 500:
            return "Legend"
        else:
            return "G.O.A.T"


def main():
    introduction()
    position = choose_position()
    NationA = better_nations()
    NationB = mid_nations()
    NationC = bad_nations()
    nation = nationality(NationA, NationB, NationC)
    ATeam = big_teams()
    BTeam = small_teams()
    team_name = choose_academy(ATeam, BTeam)
    team_history = [team_name]  # Initialize the list with the starting team
    current_team = sim(ATeam, BTeam, team_name, nation)
    player_stats = stats(position, nation, NationA, NationB, team_name)
    player_status = get_player_status(
        player_stats,
        position)  # Call the function and store the result in player_status

    while True:
        choice = input(
            "\n\n\nWhat would you like to do? (A: Check your status, V: View career stats, or Q: Quit): "
        ).lower()
        if choice == "a":
            print(
                f"Your Player Status: {player_status}")  # Print player status
        elif choice == "v":
            print("\nYour Career Stats:")
            for stat, value in player_stats.items():
                print(f"{stat}: {value}")
        elif choice == "q":
            print("\nThank you for playing the Football Career Simulator!")
            break
        else:
            print(
                "Invalid choice. Please enter 'A' to advance, 'V' to view stats, or 'Q' to quit."
            )


if __name__ == "__main__":
    main()
