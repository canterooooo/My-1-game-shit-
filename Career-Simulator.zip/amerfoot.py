import random

def introduction():
  print("Welcome to the American Football Career Simulator!")
  print("\nIn this game, you will experience the entire journey of an American football player, from your early days on the field to managing a team. Your ultimate goal is to reach the peak of your career and become a legendary football figure.")



def get_college():
  colleges = [
      "University of Alabama",
      "Ohio State University",
      "University of Oklahoma",
      "University of Southern California (USC)",
      "University of Notre Dame",
      "University of Michigan",
      "Clemson University",
      "University of Texas at Austin",
      "Florida State University",
      "University of Florida",
      "Louisiana State University (LSU)",
      "University of Miami",
      "Penn State University",
      "University of Nebraska",
      "University of Georgia"
  ]
  return random.choice(colleges)

def get_big_team():
  big_teams = [
    "Indianapolis Colts (AFC South)",
    "Tennessee Titans (AFC South)",
    "Cleveland Browns (AFC North)",
    "Las Vegas Raiders (AFC West)",
    "Los Angeles Chargers (AFC West)",
    "Dallas Cowboys (NFC East)",
    "Philadelphia Eagles (NFC East)",
    "Minnesota Vikings (NFC North)",
    "Los Angeles Rams (NFC West)",
    "San Francisco 49ers (NFC West)",
    "Seattle Seahawks (NFC West)",
    "New England Patriots (AFC East)",
    "Buffalo Bills (AFC East)",
    "Baltimore Ravens (AFC North)",
    "Pittsburgh Steelers (AFC North)",
    "Kansas City Chiefs (AFC West)"
    "Green Bay Packers (NFC North)",
    "Tampa Bay Buccaneers (NFC South)",
  ]
  return random.choice(big_teams)

def get_small_team():
  small_teams = [
      "Miami Dolphins (AFC East)",
      "New York Jets (AFC East)",
      "Houston Texans (AFC South)",
      "Denver Broncos (AFC West)",
      "New York Giants (NFC East)",
      "Washington Football Team (NFC East)",
      "Chicago Bears (NFC North)",
      "Detroit Lions (NFC North)",
      "Atlanta Falcons (NFC South)",
      "Carolina Panthers (NFC South)",
      "New Orleans Saints (NFC South)",
      "Arizona Cardinals (NFC West)",
      "Houston Texans (AFC South)"
  ]
  return random.choice(small_teams)


def choose_position():
  print("Choose your American football position:")
  print("1. Quarterback")
  print("2. Running Back")
  print("3. Wide Receiver")
  print("4. Tight End")
  print("5. Offensive Lineman")
  print("6. Defensive Lineman")
  print("7. Linebacker")
  print("8. Cornerback")
  print("9. Safety")
  while True:
      choice = input("Enter the number of your choice: ")
      if choice in ["1", "2", "3", "4", "5", "6", "7", "8", "9"]:
          positions = {
              1: "Quarterback",
              2: "Running Back",
              3: "Wide Receiver",
              4: "Tight End",
              5: "Offensive Lineman",
              6: "Defensive Lineman",
              7: "Linebacker",
              8: "Cornerback",
              9: "Safety",
          }
          position = positions[int(choice)]
          print(f"You chose to play as a {position}")
          return position
      else:
          print("Invalid choice. Please enter a number between 1 and 9.")
def choose_college():
      college = get_college()
      print(f"College - {college}")
      return college

def simulate_nfl_draft():
  print("\nNFL Draft:")
  draft_teams = [get_big_team() for _ in range(11)] + [get_small_team() for _ in range(11)]
  drafted_team = random.choice(draft_teams)
  print(f"Congratulations! You have been drafted by the {drafted_team} in the NFL Draft.")
  return drafted_team


def print_team_timeline(team_history):
  age = 23
  print("\nYour career timeline:")
  for team in team_history:
      print(f"{age} - {team}")
      age += 2
  print(f"Retired at {age} years old")

def sim(ATeam, BTeam, drafted_team):
  age = 23
  chosen_team = drafted_team
  current_team = drafted_team
  num_options = .5
  team_history = [current_team]
  contract_duration = 0

  while age <= 34:
      print(f"\nAge - {age}")

      if contract_duration >= 1:
          print(f"You are currently under contract with {current_team} for {contract_duration} more years.")

          while True:
              decision = input("Do you want to stay (s) or request a trade (t)?: ").strip().lower()

              if decision == "s":
                  print(f"You stayed at {current_team}")
                  break
              elif decision == "t":
                  print("You requested a trade \n")
                  tradefile = random.randint(1, 3)
                  if tradefile == 1:
                      print(f"You requested a trade but no teams wanted you, and {current_team} felt disrespected, so they terminated your contract")
                      contract_duration = 0
                      break
                  elif tradefile == 2:
                      print(f"You requested a trade, and the {current_team} approved it")
                      num_options = random.randint(1, 4)
                      break
                  elif tradefile == 3:
                      print(f"{current_team} thinks that you are a valuable player and can't afford to let you go")
                      num_options = 0
                      break
              else:
                  print("Invalid input. Please try again.")
                  continue

      if contract_duration == 1:
          print("You will be a free agent next year")

      if age >= 34:
          retirement_option = retirement(ATeam, BTeam, current_team)
          current_team = retirement_option
          team_history.append(current_team)
          print_team_timeline(team_history)
          explode = random.randint(1,3)
          if explode == 1:
            age += 4
          elif explode == 2:
            age += 2
          else:
            age += 1
          return retirement_option

      if age > 23 and contract_duration > 0:
          terminate = random.randint(1, 5)
          if terminate == 1:
              print(f"Your contract with {current_team} was terminated")
              contract_duration = 0

      teams = random.randint(1, 4) if age == 23 else random.randint(1, 4)
      option1, price1, contract1 = get_team_and_price(teams, current_team)
      option2, price2, contract2 = get_team_and_price(teams, current_team)
      option3, price3, contract3 = get_team_and_price(teams, current_team)

      if age == 23:
          print(f"You are currently at {chosen_team} on a {contract1} year contract")
          contract_duration += contract1
          age += 2
          contract_duration -= 2
          continue

      while True:
          if contract_duration == 0:
              print("You are a free agent")
              num_options = random.randint(1, 4)
              current_team = "Free Agent"
          else:
              print(f"You are currently with {current_team} for {contract_duration} years")

          if age > 23:
              if num_options == 1:
                  decision = input(f"Do you want to go to {option1} for £{price1}M on a {contract1} year contract (y/n)?: ").strip().lower()
              elif num_options == 2:
                  decision = input(f"Do you want to go to {option2} for £{price2}M on a {contract2} year contract (y/n)?: ").strip().lower()
              elif num_options == 3:
                  decision = input(f"Do you want to go to {option1} for £{price1}M on a {contract1} year contract or go to {option2} for £{price2}M on a {contract2} year contract (1 or 2): ")
              elif num_options == 5:
                  decision = input(f"Do you want to go to\n(1) {option1} for £{price1}M on a {contract1} year contract,\n(2) {option2} for £{price2}M on a {contract2} year contract\nstay at (3) {current_team} for an extra {contract3} years(1, 2, or 3)?: ").strip()
              elif num_options == 4:
                  if contract_duration <= 1:
                      print(f"No teams want you, so you stay as a free agent")
                      break
                  else:
                      print(f"No teams want you, so you stay with {current_team}")
                      break

              if decision == "y" or "1" and num_options == 1 or 3:
                      chosen_team = option1
                      contract_duration += contract1 
                      print(f"You moved to {chosen_team} on a {contract_duration} year contract")
              elif decision == "y" or "2" and num_options == 2 or 3:
                      chosen_team = option2
                      contract_duration += contract2
                      print(f"You moved to {chosen_team} on a {contract_duration} year contract")
              elif decision == "n":
                  chosen_team = current_team
                  if contract_duration > 0:
                      print(f"You stayed at {current_team}")
                      print(f"You have {contract_duration} years left on your contract")
                  else:
                      print(f"You stayed as a free agent")
              else:
                  print("Invalid input. Please enter 'y' or 'n'")
                  continue

              break
          elif num_options == 3 or num_options == 5:
              decision = input("Enter your choice (1, 2, or 3): ")

      current_team = chosen_team
      team_history.append(current_team)
      age += 2
      contract_duration -= 2
  print_team_timeline(team_history)
  return current_team

def get_team_and_price(teams, current_team):
  if teams == 1:
      team = get_big_team()
      while team == current_team:
          team = get_big_team()
      price = round(random.uniform(2.1, 100), 1)
      contract = random.randint(2, 10)
  else:
      team = get_small_team()
      while team == current_team:
          team = get_small_team()
      price = round(random.uniform(2.1, 50), 1)
      contract = random.randint(2, 5)
  return team, price, contract
def retirement(ATeam, BTeam, current_team):
  print("Retirement\nChoose where you are going to retire.")
  print(f"(1) {ATeam}\n(2) {BTeam}\n(3) {current_team}")

  while True:
      decision = input("Enter the number of the team where you want to retire: ")
      if decision in ["1", "2", "3"]:
          if decision == "1":
              print(f"You retired at {ATeam}")
              return ATeam
          elif decision == "2":
              print(f"You retired at {BTeam}")
              return BTeam
          elif decision == "3":
              print(f"You retired at {current_team}")
              return current_team
      else:
          print("Invalid input. Please try again.")

def stats(position, team_name, contract_duration):
  statistics = {
      "Position": position,
      "Games Played": random.randint(50, 200),
      "Passing Yards": random.randint(1000, 50000),
      "Rushing Yards": random.randint(0, 20000),
      "Touchdowns": random.randint(0, 50),
      "Interceptions": random.randint(0, 20),
      "Receptions": random.randint(0, 500),
      "Tackles": random.randint(0, 300),
      "Sacks": random.randint(0, 20),
      "Interceptions Thrown": random.randint(0, 10),
      "Super Bowl Wins": random.randint(0, 7),
      "MVP Awards": random.randint(0, 3),
      "Pro Bowl Appearances": random.randint(0, 10),
      "Defensive Player of the Year Awards": random.randint(0, 3)
  }
  
  if position == "Quarterback":
      statistics["Passing Yards"] = random.randint(2000, 50000)
      statistics["Touchdowns"] = random.randint(10, 40)
      statistics["Interceptions Thrown"] = random.randint(0, 10)
  elif position == "Running Back":
      statistics["Rushing Yards"] = random.randint(500, 20000)
      statistics["Touchdowns"] = random.randint(5, 20)
      statistics["Receptions"] = random.randint(10, 100)
  elif position == "Wide Receiver":
      statistics["Receptions"] = random.randint(40, 150)
      statistics["Receiving Yards"] = random.randint(500, 15000)
      statistics["Touchdowns"] = random.randint(3, 15)
  elif position == "Defensive Lineman":
      statistics["Tackles"] = random.randint(20, 150)
      statistics["Sacks"] = random.randint(3, 15)
  elif position == "Linebacker":
      statistics["Tackles"] = random.randint(40, 200)
      statistics["Sacks"] = random.randint(5, 25)
      statistics["Interceptions"] = random.randint(0, 5)
  elif position == "Defensive Back":
      statistics["Tackles"] = random.randint(30, 150)
      statistics["Interceptions"] = random.randint(2, 10)
  
  # Reduce stats if the player is a free agent
  if contract_duration == 0:
      for stat in statistics:
          if isinstance(statistics[stat], int):
              statistics[stat] = max(0, statistics[stat] - random.randint(5, 20))
  
  return statistics
  
def get_player_status(player_stats, position):
  touchdowns = player_stats.get("Touchdowns", 0)
  super_bowl_wins = player_stats.get("Super Bowl Wins", 0)
  mvp_awards = player_stats.get("MVP Awards", 0)
  pro_bowl_appearances = player_stats.get("Pro Bowl Appearances", 0)
  dpoy_awards = player_stats.get("Defensive Player of the Year Awards", 0)

  if position == "Quarterback" and mvp_awards >= 2:
    return "Franchise Quarterback"
  elif position in ["Running Back", "Wide Receiver"] and touchdowns >= 10:
    return "Star Player"
  elif position == "Defensive Lineman" and dpoy_awards >= 2:
    return "Dominant Defender"
  elif super_bowl_wins >= 3 or pro_bowl_appearances >= 5:
    return "Veteran Leader"
  else:
    return "Solid Contributor"

def footmain():
      introduction()
      position = choose_position()
      ATeam = get_big_team()
      BTeam = get_small_team()
      team_name = choose_college()
      drafted_team = simulate_nfl_draft()
      team_history = [team_name, drafted_team]
      current_team = sim(ATeam, BTeam, drafted_team)
      contract_duration = 2
      player_stats = stats(position, drafted_team, contract_duration)
      player_status = get_player_status(player_stats, position)

      while True:
          choice = input("\n\n\nWhat would you like to do? (A: Check your status, V: View career stats, or Q: Quit): ").lower()
          if choice == "a":
              print(f"Your Player Status: {player_status}")
          elif choice == "v":
              print("\nYour Career Stats:")
              for stat, value in player_stats.items():
                  print(f"{stat}: {value}")
          elif choice == "q":
              print("\nThank you for playing the Basketball Career Simulator!")
              break
          else:
              print("Invalid choice. Please enter 'A' to check your status, 'V' to view stats, or 'Q' to quit.")

if __name__ == "__main__":
      footmain()
