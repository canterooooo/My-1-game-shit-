import random

def introduction():
      print("Welcome to the Basketball Career Simulator!")
      print("\nIn this game, you will experience the entire journey of a basketball player, from your early days on the court to managing a team. Your ultimate goal is to reach the peak of your career and become a legendary basketball figure.")

def get_college():
      colleges = [
          "University of North Carolina at Chapel Hill",
          "Duke University",
          "University of Kentucky",
          "University of Kansas",
          "University of California, Los Angeles (UCLA)",
          "University of Connecticut",
          "Syracuse University",
          "University of Michigan",
          "University of Louisville",
          "Indiana University",
          "University of Arizona",
          "Michigan State University",
          "Villanova University",
          "University of Virginia",
          "University of Florida"
      ]
      return random.choice(colleges)

def get_big_team():
      big_teams = [
      "Boston Celtics (Atlantic)",
      "Brooklyn Nets (Atlantic)",
      "Milwaukee Bucks (Central)",
      "Philadelphia 76ers (Atlantic)",
      "Miami Heat (Southeast)",
      "Toronto Raptors (Atlantic)",
      "Golden State Warriors (Pacific)",
      "LA Clippers (Pacific)",
      "Los Angeles Lakers (Pacific)",
      "Phoenix Suns (Pacific)",
      "Utah Jazz (Northwest)",
      "Denver Nuggets (Northwest)",
      "Chicago Bulls (Central)",
      "Dallas Mavericks (Southwest)"
  ]
      return random.choice(big_teams)

def get_small_team():
      small_teams = [
      "Cleveland Cavaliers (Central)",
      "Detroit Pistons (Central)",
      "New York Knicks (Atlantic)",
      "Brooklyn Nets (Atlantic)",
      "Minnesota Timberwolves (Northwest)",
      "Oklahoma City Thunder (Northwest)",
      "Portland Trail Blazers (Northwest)",
      "Sacramento Kings (Pacific)",
      "San Antonio Spurs (Southwest)",
      "New Orleans Pelicans (Southwest)",
      "Houston Rockets (Southwest)",
      "Orlando Magic (Southeast)",
      "Washington Wizards (Southeast)",
      "Indiana Pacers (Central)",
      "Atlanta Hawks (Southeast)",
      "Charlotte Hornets (Southeast)",
      "Memphis Grizzlies (Southwest)"
  ]
      return random.choice(small_teams)

def choose_position():
      print("Choose your basketball position:")
      print("1. Point Guard")
      print("2. Shooting Guard")
      print("3. Small Forward")
      print("4. Power Forward")
      print("5. Center")
      while True:
          choice = input("Enter the number of your choice: ")
          if choice in ["1", "2", "3", "4", "5"]:
              positions = {1: "Point Guard", 2: "Shooting Guard", 3: "Small Forward", 4: "Power Forward", 5: "Center"}
              position = positions[int(choice)]
              print(f"You chose to play as a {position}")
              return position
          else:
              print("Invalid choice. Please enter a number between 1 and 5.")

def choose_college():
      college = get_college()
      print(f"College - {college}")
      return college

def simulate_draft():
  print("\nBasketball Draft:")
  draft_teams = [get_big_team() for _ in range(14)] + [get_small_team() for _ in range(16)]
  drafted_team = random.choice(draft_teams)
  print(f"Congratulations! You have been drafted by the {drafted_team} in the NBA Draft.")
  return drafted_team

def print_team_timeline(team_history):
  age = 19
  print("\nYour career timeline:")
  for team in team_history:
      print(f"{age} - {team}")
      age += 2
  print(f"Retired at {age} years old")

def sim(ATeam, BTeam, drafted_team):
  age = 19
  chosen_team = drafted_team
  current_team = drafted_team
  num_options = .5
  team_history = [current_team]
  contract_duration = 0

  while age <= 34:
      print(f"\nAge - {age}")

      if contract_duration >= 1:
          print(f"You are currently under contract with {current_team} for {contract_duration} more years.")

          while True:
              decision = input("Do you want to stay (s) or request a trade (t)?: ").strip().lower()

              if decision == "s":
                  print(f"You stayed at {current_team}")
                  break
              elif decision == "t":
                  print("You requested a trade \n")
                  tradefile = random.randint(1, 3)
                  if tradefile == 1:
                      print(f"You requested a trade but no teams wanted you, and {current_team} felt disrespected, so they terminated your contract")
                      contract_duration = 0
                      break
                  elif tradefile == 2:
                      print(f"You requested a trade, and the {current_team} approved it")
                      num_options = random.randint(1, 4)
                      break
                  elif tradefile == 3:
                      print(f"{current_team} thinks that you are a valuable player and can't afford to let you go")
                      num_options = 0
                      break
              else:
                  print("Invalid input. Please try again.")
                  continue

      if contract_duration == 1:
          print("You will be a free agent next year")

      if age >= 34:
          retirement_option = retirement(ATeam, BTeam, current_team)
          current_team = retirement_option
          team_history.append(current_team)
          print_team_timeline(team_history)
          explode = random.randint(1,3)
          if explode == 1:
            age += 4
          elif explode == 2:
            age += 2
          else:
            age += 1
          return retirement_option

      if age > 19 and contract_duration > 0:
          terminate = random.randint(1, 5)
          if terminate == 1:
              print(f"Your contract with {current_team} was terminated")
              contract_duration = 0

      teams = random.randint(1, 4) if age == 19 else random.randint(1, 4)
      option1, price1, contract1 = get_team_and_price(teams, current_team)
      option2, price2, contract2 = get_team_and_price(teams, current_team)
      option3, price3, contract3 = get_team_and_price(teams, current_team)

      if age == 19:
          print(f"You are currently at {chosen_team} on a {contract1} year contract")
          contract_duration += contract1
          age += 2
          contract_duration -= 2
          continue

      while True:
          if contract_duration == 0:
              print("You are a free agent")
              num_options = random.randint(1, 4)
              current_team = "Free Agent"
          else:
              print(f"You are currently with {current_team} for {contract_duration} years")

          if age > 19:
              if num_options == 1:
                  decision = input(f"Do you want to go to {option1} for £{price1}M on a {contract1} year contract (y/n)?: ").strip().lower()
              elif num_options == 2:
                  decision = input(f"Do you want to go to {option2} for £{price2}M on a {contract2} year contract (y/n)?: ").strip().lower()
              elif num_options == 3:
                  decision = input(f"Do you want to go to {option1} for £{price1}M on a {contract1} year contract or go to {option2} for £{price2}M on a {contract2} year contract (1 or 2): ")
              elif num_options == 5:
                  decision = input(f"Do you want to go to\n(1) {option1} for £{price1}M on a {contract1} year contract,\n(2) {option2} for £{price2}M on a {contract2} year contract\nstay at (3) {current_team} for an extra {contract3} years(1, 2, or 3)?: ").strip()
              elif num_options == 4:
                  if contract_duration <= 1:
                      print(f"No teams want you, so you stay as a free agent")
                      break
                  else:
                      print(f"No teams want you, so you stay with {current_team}")
                      break

              if decision == "y" or "1" and num_options == 1 or 3:
                      chosen_team = option1
                      contract_duration += contract1 
                      print(f"You moved to {chosen_team} on a {contract_duration} year contract")
              elif decision == "y" or "2" and num_options == 2 or 3:
                      chosen_team = option2
                      contract_duration += contract2
                      print(f"You moved to {chosen_team} on a {contract_duration} year contract")
              elif decision == "n":
                  chosen_team = current_team
                  if contract_duration > 0:
                      print(f"You stayed at {current_team}")
                      print(f"You have {contract_duration} years left on your contract")
                  else:
                      print(f"You stayed as a free agent")
              else:
                  print("Invalid input. Please enter 'y' or 'n'")
                  continue

              break
          elif num_options == 3 or num_options == 5:
              decision = input("Enter your choice (1, 2, or 3): ")

      current_team = chosen_team
      team_history.append(current_team)
      age += 2
      contract_duration -= 2
  print_team_timeline(team_history)
  return current_team

def get_team_and_price(teams, current_team):
  if teams == 1:
      team = get_big_team()
      while team == current_team:
          team = get_big_team()
      price = round(random.uniform(2.1, 100), 1)
      contract = random.randint(2, 10)
  else:
      team = get_small_team()
      while team == current_team:
          team = get_small_team()
      price = round(random.uniform(2.1, 50), 1)
      contract = random.randint(2, 5)
  return team, price, contract

def retirement(ATeam, BTeam, current_team):
  print("Retirement\nChoose where you are going to retire.")
  print(f"(1) {ATeam}\n(2) {BTeam}\n(3) {current_team}")

  while True:
      decision = input("Enter the number of the team where you want to retire: ")
      if decision in ["1", "2", "3"]:
          if decision == "1":
              print(f"You retired at {ATeam}")
              return ATeam
          elif decision == "2":
              print(f"You retired at {BTeam}")
              return BTeam
          elif decision == "3":
              print(f"You retired at {current_team}")
              return current_team
      else:
          print("Invalid input. Please try again.")

def stats(position, team_name):
      statistics = {
          "Position": position,
          "Games Played": random.randint(200, 1400),
          "Points": random.randint(0, 30000),
          "Assists": random.randint(0, 15000),
          "Rebounds": random.randint(0, 15000),
          "Steals": random.randint(0, 3000),
          "Blocks": random.randint(0, 3000),
          "Three-Pointers Made": random.randint(0, 3000),
          "Free Throws Made": random.randint(0, 5000),
          "Championships": random.randint(0, 22),
          "MVP Awards": random.randint(0, 12),
          "All-Star Appearances": random.randint(0, 15),
          "Finals MVP Awards": random.randint(0, 6)
      }

      if position == "Point Guard":
          statistics["Assists"] = random.randint(5000, 12000)
          statistics["Points"] = random.randint(5000, 25000)
      elif position == "Shooting Guard":
          statistics["Points"] = random.randint(8000, 30000)
          statistics["Three-Pointers Made"] = random.randint(500, 3000)
      elif position == "Small Forward":
          statistics["Points"] = random.randint(7000, 28000)
          statistics["Rebounds"] = random.randint(2000, 10000)
      elif position == "Power Forward":
          statistics["Points"] = random.randint(6000, 26000)
          statistics["Rebounds"] = random.randint(3000, 15000)
          statistics["Blocks"] = random.randint(500, 3000)
      elif position == "Center":
          statistics["Points"] = random.randint(5000, 24000)
          statistics["Rebounds"] = random.randint(4000, 20000)
          statistics["Blocks"] = random.randint(1000, 6000)

  # Reduce stats if the player is a free agent
      if contract_duration == 0:
        for stat in statistics:
          if isinstance(statistics[stat], int):
              statistics[stat] = max(0, statistics[stat] - random.randint(5, 20))
            
      return statistics

def get_player_status(player_stats, position):
      points = player_stats.get("Points", 0)
      assists = player_stats.get("Assists", 0)
      championships = player_stats.get("Championships", 0)
      all_star_appearances = player_stats.get("All-Star Appearances", 0)
      mvp_awards = player_stats.get("MVP Awards", 0)

      if (position.lower() == "point guard" or position.lower() == "shooting guard") and mvp_awards >= 3:
          return "Superstar"
      elif (position.lower() != "point guard" and position.lower() != "shooting guard") and championships >= 3:
          return "Superstar"
      elif points + assists < 15000:
          return "Role Player"
      elif 15000 <= points + assists < 25000:
          return "Star Player"
      elif 25000 <= points + assists < 35000:
          return "All-Star"
      else:
          return "Superstar"

def basmain():
      introduction()
      position = choose_position()
      contract_duration = 1
      ATeam = get_big_team()
      BTeam = get_small_team()
      team_name = choose_college()
      drafted_team = simulate_draft()
      team_history = [team_name, drafted_team]
      current_team = sim(ATeam, BTeam, drafted_team)
      player_stats = stats(position, drafted_team)
      player_status = get_player_status(player_stats, position)

      while True:
          choice = input("\n\n\nWhat would you like to do? (A: Check your status, V: View career stats, or Q: Quit): ").lower()
          if choice == "a":
              print(f"Your Player Status: {player_status}")
          elif choice == "v":
              print("\nYour Career Stats:")
              for stat, value in player_stats.items():
                  print(f"{stat}: {value}")
          elif choice == "q":
              print("\nThank you for playing the Basketball Career Simulator!")
              break
          else:
              print("Invalid choice. Please enter 'A' to check your status, 'V' to view stats, or 'Q' to quit.")

if __name__ == "__main__":
      basmain()
